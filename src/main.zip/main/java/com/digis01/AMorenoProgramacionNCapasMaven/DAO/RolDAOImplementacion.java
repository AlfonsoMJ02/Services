package com.digis01.AMorenoProgramacionNCapasMaven.DAO;

import com.digis01.AMorenoProgramacionNCapasMaven.ML.Result;
import com.digis01.AMorenoProgramacionNCapasMaven.ML.Rol;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class RolDAOImplementacion implements IRol{
    
    @Autowired
    private  JdbcTemplate jdbcTemplate;
    
    @Override
    public Result GetAll(){
        Result result = new Result();
        
        try{
            jdbcTemplate.execute("{CALL RolGetAllSP(?)}", 
                    (CallableStatementCallback<Boolean>) callableStatement -> {
                        
                        callableStatement.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
                        callableStatement.execute();
                        
                        ResultSet resultSet = (ResultSet) callableStatement.getObject(1);
                        
                        result.objects = new ArrayList<>();
                        
                        while (resultSet.next()){
                            Rol rol = new Rol();
                            rol.setIdRol(resultSet.getInt("IdRol"));
                            rol.setNombre(resultSet.getString("Nombre"));
                            
                            result.objects.add(rol);
                        }
                        result.correct = true;
                        return true;
                    });
        } catch(Exception ex){
            result.correct = false;
            result.errorMessage = ex.getLocalizedMessage();
            result.ex = ex;
        }
        return result;
    }
}
